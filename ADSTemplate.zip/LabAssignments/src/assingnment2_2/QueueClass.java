package assingnment2_2;

import java.util.ArrayList;

public class QueueClass<T> implements QueueInterface<T> {
	int size;
	int rear = -1;
	int front = -1;
	ArrayList<T> queue;

	public QueueClass(int size) {

		this.size = size;
		queue = new ArrayList<>(size);
	}

	@Override
	public void enQueue(T element) {
		if (isFull())
			System.out.println("Queue is full");
		else if (isEmpty()) {
			front++;
			rear++;
			queue.add(element);
		} else {
			rear++;
			queue.add(element);
		}

	}

	@Override
//	In a method with a return type
//	every possible path must return a value.
	public T deQueue() {
		if (isEmpty())
			System.out.println("Queue is Empty");
		else if (front == rear) {
			T removeElement = queue.get(front);

			front = rear = -1;
			queue.clear();
			return removeElement;

		} else {

			T removeElement = queue.get(front);

			front++;
			return removeElement;
		}
		return null;

	}

	@Override
	public boolean isEmpty() {
		if (front == -1 && rear == -1)
			return true;
		else
			return false;
	}

	@Override
	public boolean isFull() {
		if (rear + 1 < size)
			return false;
		else
			return true;

	}

	@Override
	public void display() {
		if (isEmpty())
			System.out.println("[ ]");
		else {
			for (int i = front; i <= rear; i++) {
				System.out.print(queue.get(i) + " ");
			}
			System.out.println();
		}

	}

}
