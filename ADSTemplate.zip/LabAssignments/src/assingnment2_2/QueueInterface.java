package assingnment2_2;

public interface QueueInterface<T> {
public void enQueue(T element);
public T deQueue();
public boolean isEmpty();
public boolean isFull();
public void display();

	
}
