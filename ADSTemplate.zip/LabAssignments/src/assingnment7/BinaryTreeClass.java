package assingnment7;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTreeClass<T> implements BinaryTreeInterface<T> {
    static class Node<T> {
        T data;
        Node<T> left, right;

        Node(T data) {
            this.data = data;
            left = null;
            right = null;
        }
    }

    private Node<T> root;

    public BinaryTreeClass() {
        root = null;
    }

    @Override
    public void add(T value) {
        if (root == null) {
            root = new Node<>(value);
            return;
        }

        Queue<Node<T>> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            Node<T> temp = queue.poll();

            if (temp.left == null) {
                temp.left = new Node<>(value);
                break;
            } else {
                queue.add(temp.left);
            }

            if (temp.right == null) {
                temp.right = new Node<>(value);
                break;
            } else {
                queue.add(temp.right);
            }
        }
    }

    @Override
    public void preOrderTraversal() {
        preOrderTraversal(root);
        System.out.println();
    }

    private void preOrderTraversal(Node<T> node) {
        if (node == null) return;

        System.out.print(node.data + " ");
        preOrderTraversal(node.left);
        preOrderTraversal(node.right);
    }

    @Override
    public void postOrderTraversal() {
        postOrderTraversal(root);
        System.out.println();
    }

    private void postOrderTraversal(Node<T> node) {
        if (node == null) return;

        postOrderTraversal(node.left);
        postOrderTraversal(node.right);
        System.out.print(node.data + " ");
    }

    @Override
    public int countNodes() {
        return countNodes(root);
    }

    private int countNodes(Node<T> node) {
        if (node == null) return 0;

        return 1 + countNodes(node.left) + countNodes(node.right);
    }

    @Override
    public int countLeafNodes() {
        return countLeafNodes(root);
    }

    private int countLeafNodes(Node<T> node) {
        if (node == null) return 0;

        if (node.left == null && node.right == null) {
            return 1;
        }

        return countLeafNodes(node.left) + countLeafNodes(node.right);
    }

    @Override
    public int countNodesWithValue(T value) {
        return countNodesWithValue(root, value);
    }

    private int countNodesWithValue(Node<T> node, T value) {
        if (node == null) return 0;

        int count = node.data.equals(value) ? 1 : 0;
        return count + countNodesWithValue(node.left, value) + countNodesWithValue(node.right, value);
    }
}
