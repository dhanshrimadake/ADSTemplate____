package assingnment7;

public interface BinaryTreeInterface<T> {
    void add(T value);
    void preOrderTraversal();
    void postOrderTraversal();
    int countNodes();
    int countLeafNodes();
    int countNodesWithValue(T value);
}
