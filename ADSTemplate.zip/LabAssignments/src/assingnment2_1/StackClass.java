package assingnment2_1;

import java.util.ArrayList;

public class StackClass<T> implements StackInterface<T> {
    private int size;
    private int top;
    private ArrayList<T> stack;

    public StackClass(int size) {
        this.size = size;
        this.top = -1;
        this.stack = new ArrayList<>(size);
    }

    @Override
    public void push(T element) {
        if (isFull()) {
            System.out.println("Stack is full");
        } else {
            stack.add(element);
            top++;
        }
    }

    @Override
    public T pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return null;
        } else {
            T element = stack.remove(top);
            top--;
            return element;
        }
    }

    @Override
    public boolean isEmpty() {
        return top == -1;
    }

    @Override
    public boolean isFull() {
        return top + 1 == size;
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("[ ]");
        } else {
            for (int i = 0; i <= top; i++) {
                System.out.print(stack.get(i) + " ");
            }
            System.out.println();
        }
    }
}
