package assingnment2_1;

import java.util.Scanner;

public class StackDemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements");
        int size = sc.nextInt();
        StackClass<Integer> stack = new StackClass<>(size);

        while (true) {
            System.out.println("1. Push()\n" + "2. Pop()\n" + "3. isEmpty()\n" + "4. isFull()\n"
                    + "5. Display Stack \n" + "6. Exit\n");

            switch (sc.nextInt()) {
                case 1:
                    stack.push(sc.nextInt());
                    break;

                case 2:
                    System.out.println(stack.pop());
                    break;

                case 3:
                    if (stack.isEmpty())
                        System.out.println("Stack is empty");
                    else
                        System.out.println("Stack is not empty");
                    break;

                case 4:
                    if (stack.isFull())
                        System.out.println("Stack is full");
                    else
                        System.out.println("Stack is not full");
                    break;

                case 5:
                    stack.display();
                    break;

                case 6:
                    System.exit(0);
            }
        }
    }
}
