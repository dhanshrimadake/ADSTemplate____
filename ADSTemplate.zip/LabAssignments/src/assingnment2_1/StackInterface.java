package assingnment2_1;

public interface StackInterface<T> {
    void push(T element);
    T pop();
    boolean isEmpty();
    boolean isFull();
    void display();
}
