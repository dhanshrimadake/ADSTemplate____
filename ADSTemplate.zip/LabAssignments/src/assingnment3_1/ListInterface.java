package assingnment3_1;

public interface ListInterface<T extends Comparable<T>> {
    void display();
    boolean isEmpty();
    void addAtFirst(T element);
    void addAtLast(T element);
    void addAtPosition(int position, T element);
    T deleteAtFirst();
    T deleteAtLast();
    T deleteAtPosition(int position);
    void sortList();
}
