package assingnment3_1;

import java.util.Scanner;

public class ListDemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ListClass<Integer> list = new ListClass<>();

        while (true) {
            System.out.println("1. Add at First\n" + "2. Add at Last\n" + "3. Add at Position\n"
                    + "4. Delete at First\n" + "5. Delete at Last\n" + "6. Delete at Position\n"
                    + "7. Display List\n" + "8. Check if Empty\n" + "9. Sort List\n" + "10. Exit\n");

            switch (sc.nextInt()) {
                case 1:
                    System.out.println("Enter element to add at first:");
                    list.addAtFirst(sc.nextInt());
                    break;

                case 2:
                    System.out.println("Enter element to add at last:");
                    list.addAtLast(sc.nextInt());
                    break;

                case 3:
                    System.out.println("Enter position and element to add:");
                    int pos = sc.nextInt();
                    int element = sc.nextInt();
                    list.addAtPosition(pos, element);
                    break;

                case 4:
                    System.out.println("Deleted Element at First: " + list.deleteAtFirst());
                    break;

                case 5:
                    System.out.println("Deleted Element at Last: " + list.deleteAtLast());
                    break;

                case 6:
                    System.out.println("Enter position to delete:");
                    int position = sc.nextInt();
                    System.out.println("Deleted Element at Position: " + list.deleteAtPosition(position));
                    break;

                case 7:
                    list.display();
                    break;

                case 8:
                    if (list.isEmpty())
                        System.out.println("List is empty");
                    else
                        System.out.println("List is not empty");
                    break;

                case 9:
                    list.sortList();
                    break;

                case 10:
                    System.exit(0);
            }
        }
    }
}
