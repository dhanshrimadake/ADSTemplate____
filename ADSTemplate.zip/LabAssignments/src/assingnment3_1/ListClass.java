package assingnment3_1;

import java.util.ArrayList;
import java.util.Collections;

public class ListClass<T extends Comparable<T>> implements ListInterface<T> {
    private Node<T> head;

    public ListClass() {
        this.head = null;
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("[ ]");
        } else {
            Node<T> current = head;
            while (current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
            System.out.println();
        }
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public void addAtFirst(T element) {
        Node<T> newNode = new Node<>(element);
        newNode.next = head;
        head = newNode;
    }

    @Override
    public void addAtLast(T element) {
        Node<T> newNode = new Node<>(element);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    @Override
    public void addAtPosition(int position, T element) {
        if (position < 1) {
            System.out.println("Invalid position");
            return;
        }
        if (position == 1) {
            addAtFirst(element);
            return;
        }
        Node<T> newNode = new Node<>(element);
        Node<T> current = head;
        for (int i = 1; i < position - 1; i++) {
            if (current != null) {
                current = current.next;
            } else {
                System.out.println("Position out of bounds");
                return;
            }
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    @Override
    public T deleteAtFirst() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return null;
        } else {
            T element = head.data;
            head = head.next;
            return element;
        }
    }

    @Override
    public T deleteAtLast() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return null;
        } else if (head.next == null) {
            T element = head.data;
            head = null;
            return element;
        } else {
            Node<T> current = head;
            while (current.next.next != null) {
                current = current.next;
            }
            T element = current.next.data;
            current.next = null;
            return element;
        }
    }

    @Override
    public T deleteAtPosition(int position) {
        if (position < 1 || isEmpty()) {
            System.out.println("Invalid position or list is empty");
            return null;
        }
        if (position == 1) {
            return deleteAtFirst();
        }
        Node<T> current = head;
        for (int i = 1; i < position - 1; i++) {
            if (current != null) {
                current = current.next;
            } else {
                System.out.println("Position out of bounds");
                return null;
            }
        }
        if (current.next != null) {
            T element = current.next.data;
            current.next = current.next.next;
            return element;
        } else {
            System.out.println("Position out of bounds");
            return null;
        }
    }

    @Override
    public void sortList() {
        if (isEmpty()) {
            System.out.println("List is empty, nothing to sort");
            return;
        }

        // Extract elements into an ArrayList
        ArrayList<T> list = new ArrayList<>();
        Node<T> current = head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }

        // Sort the ArrayList
        Collections.sort(list);

        // Rebuild the linked list with sorted elements
        current = head;
        for (T element : list) {
            current.data = element;
            current = current.next;
        }

        System.out.println("List sorted");
    }

    private static class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}
