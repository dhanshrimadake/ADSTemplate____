package assingnment3_2;

public class QueueClass<T> implements QueueInterface<T> {
    private int size;
    private int count;
    private Node<T> front;
    private Node<T> rear;

    public QueueClass(int size) {
        this.size = size;
        this.count = 0;
        this.front = this.rear = null;
    }

    @Override
    public void enQueue(T element) {
        if (isFull()) {
            System.out.println("Queue is full");
        } else {
            Node<T> newNode = new Node<>(element);
            if (isEmpty()) {
                front = rear = newNode;
            } else {
                rear.next = newNode;
                rear = newNode;
            }
            count++;
        }
    }

    @Override
    public T deQueue() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return null;
        } else {
            T element = front.data;
            front = front.next;
            if (front == null) {
                rear = null;
            }
            count--;
            return element;
        }
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public boolean isFull() {
        return count == size;
    }

    @Override
    public void display() {
        if (isEmpty()) {
            System.out.println("[ ]");
        } else {
            Node<T> current = front;
            while (current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
            System.out.println();
        }
    }

    private static class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}
