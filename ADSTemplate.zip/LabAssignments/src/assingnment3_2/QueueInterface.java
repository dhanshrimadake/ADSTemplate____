package assingnment3_2;

public interface QueueInterface<T> {
    void enQueue(T element);
    T deQueue();
    boolean isEmpty();
    boolean isFull();
    void display();
}
