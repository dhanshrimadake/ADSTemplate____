package assingnment3_2;

import java.util.Scanner;

public class QueueDemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements");
        int size = sc.nextInt();
        QueueClass<Integer> queue = new QueueClass<>(size);

        while (true) {
            System.out.println("1. Enqueue()\n" + "2. Dequeue()\n" + "3. isEmpty()\n" + "4. isFull()\n"
                    + "5. Display Queue \n" + "6. Exit\n");

            switch (sc.nextInt()) {
                case 1:
                    queue.enQueue(sc.nextInt());
                    break;

                case 2:
                    System.out.println(queue.deQueue());
                    break;

                case 3:
                    if (queue.isEmpty())
                        System.out.println("Queue is empty");
                    else
                        System.out.println("Queue is not empty");
                    break;

                case 4:
                    if (queue.isFull())
                        System.out.println("Queue is full");
                    else
                        System.out.println("Queue is not full");
                    break;

                case 5:
                    queue.display();
                    break;

                case 6:
                    System.exit(0);
            }
        }
    }
}
